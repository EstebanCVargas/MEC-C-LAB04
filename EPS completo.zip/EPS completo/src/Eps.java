import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

 class Main {

    public static void main(String[] args) throws InterruptedException {
        Queue<String> colaEspera = new LinkedList<>();
        //crea una cola vacía para almacenar los nombres de los pacientes que esperan para recibir medicamentos
        Scanner scanner = new Scanner(System.in);
        int turnoActual = 0;

        while (true) {
            System.out.println("Ingrese su nombre y apellidos: ");
            String nombre = scanner.nextLine();
            System.out.println("Ingrese su edad: ");
            int edad = scanner.nextInt();
            scanner.nextLine(); // limpia el buffer del scanner
            System.out.println("Ingrese su afiliación (POS o PC): ");
            String afiliacion = scanner.nextLine();
            System.out.println("¿Tiene alguna condición especial? (embarazo o limitación motriz): ");
            String condicionEspecial = scanner.nextLine();

            String paciente = nombre + " - " + edad + " años - Afiliación: " + afiliacion + " - Condición especial: " + condicionEspecial;
            if (edad < 12 || edad >= 60) { 
                // si el paciente es una persona de la tercera edad o menor de 12 años
                colaEspera.offer(paciente); 
                // agregar al final de la cola
            } else if (condicionEspecial.equalsIgnoreCase("embarazo")) { 
                // si el paciente es una mujer embarazada
                colaEspera.offer(paciente); 
                // agregar al final de la cola
            } else if (condicionEspecial.equalsIgnoreCase("limitación motriz")) { 
                // si el paciente tiene una limitación motriz
                colaEspera.offer(paciente); 
                // agregar al final de la cola
            } else if (afiliacion.equalsIgnoreCase("PC") || afiliacion.equalsIgnoreCase("prepagada")) { // si el paciente está afiliado a un plan complementario o prepagado
                colaEspera.offer(paciente);
                // agregar al final de la cola
            } else { // si el paciente no tiene ninguna condición especial y no está afiliado a un plan complementario o prepagado
                colaEspera.offer(paciente); // agregar al final de la cola
            }

            System.out.println("Su número de turno es: " + (colaEspera.size())); // mostrar al paciente su número de turno en la cola de espera
            System.out.println(" ");

            if (colaEspera.size() == 1) {
                // si es el primer paciente en la cola, inicia el temporizador
                turnoActual = 1;
                Thread.sleep(5000); // Espera 5 segundos para llamar al primer paciente
                System.out.println("¡Turno " + turnoActual + "! " + colaEspera.poll() + " puede pasar.");
                System.out.println(" ");
            } else if (colaEspera.size() > 1) {
                // si hay más pacientes en la cola, muestra el turno actual, el tiempo restante y los turnos pendientes
                System.out.println("Turno actual: " + turnoActual);
                System.out.println("Tiempo restante: 5 segundos");
                System.out.println("Turnos pendientes: " + (colaEspera.size() - 1));
                System.out.println(" ");
            }
            while (true) {
                    
                Thread.sleep(5000); // Espera 5 segundos para ll
                    
            }
        }
    }
 }